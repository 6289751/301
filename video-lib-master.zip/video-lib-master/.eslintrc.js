module.exports = {
  env: {
    browser: true
  },
  extends: ['airbnb-base', 'plugin:prettier/recommended']
};
